/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inf2015_refactoring;

/**
 *
 * @author je591116
 */
public class INF2015_Refactoring {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
