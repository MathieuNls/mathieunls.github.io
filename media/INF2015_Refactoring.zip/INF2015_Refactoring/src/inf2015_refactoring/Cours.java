/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inf2015_refactoring;

/**
 *
 * @author je591116
 */

  // TODO: Extraire une SUPERCLASSE puis en dériver la class demo.
public class Cours {
    String titre;
    // TODO: CREER UNE CLASSE SALLE QUI CONTIENT 1 STRING (BAT) + 1 int  numéro SALLE + Capacité
    // TODO: Extraire une Superclasse puis dériver la classe labo.
    String salle;
   

    public Cours(String titre, String salle) {
        this.titre = titre;
        this.salle = salle;
    }
    
    public String getSalle() {
        return salle;
    }

    public void setSalle(String salle) {
        this.salle = salle;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }
}
