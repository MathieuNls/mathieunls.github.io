/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inf2015_refactoring;

import java.util.Date;
import java.util.List;

/**
 *
 * @author je591116
 */
public class Etudiant extends Humain{
 
    // TODO: Renomer en codePerma
    String codePermanent;
    // TODO: Remonter dans HUMAIN
    Date dateDeNaissance;
    List<Cours> coursSuivi;
    String espacePerso;

    // FRANCISER LES PARAMETRES
    public Etudiant(String lastname, String firstname, Date dateDeNaissance){
        super(lastname, firstname);
        this.codePermanent = createCodePermanent(lastname, firstname, dateDeNaissance);
        this.dateDeNaissance = dateDeNaissance;
        // INTRODUIRE UN CHAMPS BASECOMMUNE
        this.espacePerso = "zeta/labunix/uqam/ca/"+this.codePermanent;
        System.out.println(lastname+firstname+codePermanent+dateDeNaissance);
    }
    
    private String createCodePermanent(String nom, String prenom, Date date) {
        String end = concatDate(date);
        String result = nom.substring(0, 3) + prenom.charAt(0) + end;
        this.codePermanent = result;
        return result;
    }

    // TODO inliner dans `createCodePermanent`
    private String concatDate(Date date) {
        return date.getYear() + "-" + date.getMonth();
    }

    public List<Cours> getCoursSuivi() {
        return coursSuivi;
    }

    public void setCoursSuivi(List<Cours> coursSuivi) {
        this.coursSuivi = coursSuivi;
    }

    public String getCodePermanent() {
        return codePermanent;
    }

    public void setCodePermanent(String codePermanent) {
        this.codePermanent = codePermanent;
    }

    // TODO: REMONTER DANS HUMAIN
    public Date getDateDeNaissance() {
        return dateDeNaissance;
    }

     // TODO: REMONTER DANS HUMAIN
    public void setDateDeNaissance(Date dateDeNaissance) {
        this.dateDeNaissance = dateDeNaissance;
    }
}
