/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inf2015_refactoring;

/**
 *
 * @author je591116
 */
public abstract class Humain {
    
    String nom;
    String prenom;
    //TODO: CHANGER LA VISIBILITE PUIS GETTER & SETTER
    public int age;
    
    // TODO: GENERER LES SETTERS & GETTERS POUR NOM ET PRENOM;
    public Humain(String nom, String prenom){
        this.nom = nom;
        this.prenom = prenom;
    }
}
