/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inf2015_refactoring;

/**
 *
 * @author je591116
 */
public class Demo extends Enseignement{

    public Demo(String titre, Lieu lieu) {
        super(titre, lieu);
    }
    
    

    @Override
    public String toString() {
        return "Demo{" + this.titre + this.lieu + '}';
    }

}
