/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inf2015_refactoring;

import java.util.Date;
import java.util.List;

/**
 *
 * @author je591116
 */
public class Etudiant extends Humain{
 
    String codePerma;
    List<Enseignement> coursSuivi;
    String espacePerso;
    private String baseCommune = "zeta/labunix/uqam/ca/";

    public Etudiant(String nomDeFamille, String prenom, Date dateDeNaissance){
        super(nomDeFamille, prenom);
        this.codePerma = createCodePermanent(nomDeFamille, prenom, dateDeNaissance);
        this.dateDeNaissance = dateDeNaissance;
        this.espacePerso = baseCommune+this.codePerma;
        System.out.println(nomDeFamille+prenom+codePerma+dateDeNaissance);
    }
    
    private String createCodePermanent(String nom, String prenom, Date date) {
        String end = date.getYear() + "-" + date.getMonth();
        String result = nom.substring(0, 3) + prenom.charAt(0) + end;
        this.codePerma = result;
        return result;
    }

    public List<Enseignement> getCoursSuivi() {
        return coursSuivi;
    }

    public void setCoursSuivi(List<Enseignement> coursSuivi) {
        this.coursSuivi = coursSuivi;
    }

    public String getCodePermanent() {
        return codePerma;
    }

    public void setCodePermanent(String codePermanent) {
        this.codePerma = codePermanent;
    }
}
