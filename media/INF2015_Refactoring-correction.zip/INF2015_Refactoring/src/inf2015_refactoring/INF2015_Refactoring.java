/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inf2015_refactoring;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author je591116
 */
public class INF2015_Refactoring {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Etudiant math = new Etudiant("Nayrolles", "Mathieu", 
                new Date(1989, 8, 2));
        
        Lieu salle = new Salle("PK", 7115, 25);
        
        Lieu labo = new Labo("PK-S", 1805, 50);
        
        Enseignement cours = new Cours("INF2115", salle);
        Enseignement demo = new Demo("DEMO INF2115", labo);
        
        List<Enseignement> ensiList = new ArrayList<Enseignement>();
        ensiList.add(demo);
        ensiList.add(cours);
        
        math.setCoursSuivi(ensiList);
        
        for(Enseignement enseignement : math.getCoursSuivi()){
            System.out.println(enseignement.toString());
        }
    }
}
