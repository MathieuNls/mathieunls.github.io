/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inf2015_refactoring;

/**
 *
 * @author je591116
 */
public class Enseignement  {

    
    String titre;
    Lieu lieu;
    
    public Enseignement(String titre, Lieu lieu) {
        this.titre = titre;
        this.lieu = lieu;
    }

    public Lieu getLieu() {
        return lieu;
    }

    public void setLieu(Lieu lieu) {
        this.lieu = lieu;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    
    
    
}
