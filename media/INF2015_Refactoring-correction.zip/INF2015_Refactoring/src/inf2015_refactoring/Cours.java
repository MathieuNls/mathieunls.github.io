/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inf2015_refactoring;

/**
 *
 * @author je591116
 */

public class Cours extends Enseignement {

    public Cours(String titre, Lieu lieu) {
        super(titre, lieu);
    }

    @Override
    public String toString() {
        return "Cours{" + this.titre + this.lieu + '}';
    }
    
    
   
  
}
