/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inf2015_refactoring;

/**
 *
 * @author je591116
 */
public class Lieu {

    public Lieu() {
    }
    protected String bat;
    protected int capacity;
    protected int numero;

    public String getBat() {
        return bat;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getNumero() {
        return numero;
    }

    public void setBat(String bat) {
        this.bat = bat;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
    
}
