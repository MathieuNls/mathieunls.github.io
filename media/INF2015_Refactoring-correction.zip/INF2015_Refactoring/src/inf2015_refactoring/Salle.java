/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inf2015_refactoring;

/**
 *
 * @author je591116
 */
public class Salle extends Lieu {

    public Salle(String bat, int numero, int capacity) {
        this.bat = bat;
        this.numero = numero;
        this.capacity = capacity;
    }

    @Override
    public String toString() {
        return "Salle{" + this.bat + this.numero + this.capacity +'}';
    }
    
    
    
    
    
}
